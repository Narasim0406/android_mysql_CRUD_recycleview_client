<?php
	
	define('HOST','localhost');
	define('USER','arunoms');
	define('PASS','arun@oms#2017');
	define('DB','arunoms_test');
	
	$con = mysqli_connect(HOST,USER,PASS,DB) or die('Unable to Connect');