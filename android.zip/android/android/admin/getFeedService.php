<?php 
	$id = $_GET['id'];
	
	require_once('dbConnect.php');
	
	$sql = "SELECT * FROM service WHERE sid=$id";
	$r = mysqli_query($con,$sql);
	
	$result = array();
	
	$row = mysqli_fetch_array($r);
	array_push($result,array(
			"id"=>$row['sid'],
			"name"=>$row['username'],
			"product"=>$row['service'],
			"token"=>$row['token'],
			"mobile"=>$row['mobile'],
			"deldate"=>$row['book_date'],
			"con_name"=>$row['con_name'],
			"status"=>$row['status'],
			"tokenname"=>$row['tokenname'],
			"feed"=>$row['feed'],
			"reply"=>$row['reply'],
			"hint"=>$row['hint']
		));

	echo json_encode(array('result'=>$result));
	
	mysqli_close($con);
	
?>