<?php 
	if($_SERVER['REQUEST_METHOD']=='POST'){
		$id = $_POST['id'];
// 		$name = $_POST['name'];
// 		$desg = $_POST['desg'];
// 		$sal = $_POST['salary'];
        $reply = $_POST['status'];
// 		$feed = $_POST['feed'];
// 		$hint = $_POST['reply'];
		
		require_once('dbConnect.php');
		
		$sql = "UPDATE newproduct SET reply='$reply' WHERE pid = $id;";
		
		if(mysqli_query($con,$sql)){
			echo 'Reply Updated Successfully';
		}else{
			echo 'Could Not Update Reply Try Again';
		}
		
		mysqli_close($con);
	}