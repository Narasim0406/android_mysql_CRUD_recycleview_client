<?php 
	//Importing Database Script 
	require_once('dbConnect.php');
	
// 	$status=$_GET['status'];
	//Creating sql query
	$sql = "SELECT sid,service,status,CONCAT(tokenname,token) AS tokenname FROM service ORDER BY (token) DESC";
	
	//getting result 
	$r = mysqli_query($con,$sql);
	
	//creating a blank array 
	$result = array();
	
	//looping through all the records fetched
	while($row = mysqli_fetch_array($r)){
		
		//Pushing name and id in the blank array created 
		array_push($result,array(
			"id"=>$row['sid'],
			"name"=>$row['service'],
			"status"=>$row['status'],
			"token"=>$row['tokenname']
		));
	}
	
	//Displaying the array in json format 
	echo json_encode(array('result'=>$result));
	
	mysqli_close($con);