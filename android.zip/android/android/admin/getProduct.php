<?php 
	$id = $_GET['id'];
	
	require_once('dbConnect.php');
	
	$sql = "SELECT * FROM newproduct WHERE pid=$id";
	$r = mysqli_query($con,$sql);
	
	$result = array();
	
	$row = mysqli_fetch_array($r);
	array_push($result,array(
			"id"=>$row['pid'],
			"name"=>$row['username'],
			"product"=>$row['product'],
			"token"=>$row['token'],
			"mobile"=>$row['mobile'],
			"model"=>$row['model'],
			"quantity"=>$row['quantity'],
			"deldate"=>$row['del_date'],
			"con_name"=>$row['con_name'],
			"status"=>$row['status'],
			"tokenname"=>$row['tokenname'],
			"feed"=>$row['feed'],
			"hint"=>$row['hint']
		));

	echo json_encode(array('result'=>$result));
	
	mysqli_close($con);
	
?>