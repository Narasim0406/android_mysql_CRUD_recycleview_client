<?php 
	$id = $_GET['id'];
	
	require_once('dbConnect.php');
	
	$sql = "SELECT * FROM service WHERE id=$id";
	$r = mysqli_query($con,$sql);
	
	$result = array();
	
	$row = mysqli_fetch_array($r);
	array_push($result,array(
			"id"=>$row['id'],
			"name"=>$row['username'],
			"desg"=>$row['service'],
			"salary"=>$row['token'],
			"mobile"=>$row['mobile']
		));

	echo json_encode(array('result'=>$result));
	
	mysqli_close($con);