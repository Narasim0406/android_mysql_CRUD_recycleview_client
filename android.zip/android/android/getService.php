<?php 
	$id = $_GET['id'];
	
	require_once('dbConnect.php');
	
	$sql = "SELECT * FROM service WHERE sid=$id";
	$r = mysqli_query($con,$sql);
	
	$result = array();
	
	$row = mysqli_fetch_array($r);
	array_push($result,array(
			"id"=>$row['sid'],
			"name"=>$row['username'],
			"service"=>$row['service'],
			"token"=>$row['token'],
			"mobile"=>$row['mobile'],
			"bookdate"=>$row['book_date'],
			"tokenname"=>$row['tokenname'],
			"con_name"=>$row['con_name'],
			"status"=>$row['status']
		));

	echo json_encode(array('result'=>$result));
	
	mysqli_close($con);