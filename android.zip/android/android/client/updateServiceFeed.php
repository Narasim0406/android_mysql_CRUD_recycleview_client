<?php 
	if($_SERVER['REQUEST_METHOD']=='POST'){
		$id = $_POST['id'];
// 		$name = $_POST['name'];
// 		$desg = $_POST['desg'];
// 		$sal = $_POST['salary'];
        // $status = $_POST['status'];
		$feed = $_POST['feed'];
		$hint = $_POST['hint'];
		
		require_once('dbConnect.php');
		
		$sql = "UPDATE service SET  feed = '$feed',hint='$hint' WHERE sid = $id;";
		
		if(mysqli_query($con,$sql)){
			echo 'Feedback Updated Successfully';
		}else{
			echo 'Could Not Update Feedback Try Again';
		}
		
		mysqli_close($con);
	}