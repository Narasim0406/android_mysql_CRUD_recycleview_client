 <?php

$hostname = "localhost";
$username = "arunoms";
$password = "arun@oms#2017";
$dbname = "arunoms_test";
 
 $con = mysqli_connect($hostname,$username,$password,$dbname);
 
 $np = "BS";
// $sql = "SELECT * FROM service";
// $result=$con->query($sql);
// while($row = $result->fetch_assoc())
// {
// 	$np= $row["tokenname"];
// }
$username = $_GET['username'];  
$mid = "1";
$sql = "SELECT * FROM service WHERE  token > 0";
$result=$con->query($sql);
while($row = $result->fetch_assoc())
{
	$midi = $mid;
	$midi++;
	$mid = $midi++; 
}
 
 $id = $_POST['id'];
 $username = $_POST['username'];
 $service = $_POST['service'];
 $bookdate = $_POST['book_date'];
 $conname = $_POST['con_name'];
 $mobile = $_POST['mobile'];
 $status = 'PROGRESS';
 
 $Sql_Query = "insert into service(id   ,  username  ,  service  ,  book_date ,    con_name,    mobile  , token   , tokenname, status) values 
                                  ('$id', '$username',  '$service', '$bookdate',  '$conname',  '$mobile', '$mid', '$np', '$status')";
  
 if(mysqli_query($con,$Sql_Query)){
 
 echo 'Service Booked Successfully';
 
 }
 else{
 
 echo 'Try Again';
 
 }
 mysqli_close($con);
?>