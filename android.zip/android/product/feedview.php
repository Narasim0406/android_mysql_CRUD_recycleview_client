<?php 
 
 /*
 * Created by Belal Khan
 * website: www.simplifiedcoding.net 
 * Retrieve Data From MySQL Database in Android
 */
 
 //database constants
	define('DB_HOST', 'localhost');
	define('DB_USER', 'arunoms');
	define('DB_PASS', 'arun@oms#2017');
	define('DB_NAME', 'arunoms_test');
	
 //connecting to database and getting the connection object
 $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
 
 //Checking if any error occured while connecting
 if (mysqli_connect_errno()) {
 echo "Failed to connect to MySQL: " . mysqli_connect_error();
 die();
 }
 
//  $username = $_POST['username'];
 //creating a query
 $stmt = $conn->prepare("SELECT id, title, username, feed, hint FROM feedback WHERE username = '".$_REQUEST['username']."'");
 
 //executing the query 
 $stmt->execute();
 
 //binding results to the query 
 $stmt->bind_result($id, $title, $username, $feed, $hint);
 
 $products = array(); 
 
 //traversing through all the result 
 while($stmt->fetch()){
 $temp = array();
 $temp['id'] = $id; 
 $temp['title'] = $title; 
 $temp['username'] = $username;
 $temp['feed'] = $feed;
 $temp['hint'] = $hint;
 array_push($products, $temp);
 }
 
 //displaying the result in json format 
 echo json_encode($products);
	
	