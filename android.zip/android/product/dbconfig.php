<?php
$server_name = "localhost";
$user_name = "arunoms";
$password = "arun@oms#2017";
$conn = mysql_connect($server_name, $user_name, $password) or die ('Server '. mysql_error());
$database_name= 'arunoms_test';
mysql_select_db($database_name) or die('error');
mysql_query("SET NAMES 'utf8'");
?>