 <?php
 
//This script is designed by Android-Examples.com
//Define your host here.
$hostname = "localhost";
//Define your database username here.
$username = "arunoms";
//Define your database password here.
$password = "arun@oms#2017";
//Define your database name here.
$dbname = "arunoms_test";
 
 $con = mysqli_connect($hostname,$username,$password,$dbname);
 
 $id = $_POST['id'];
 $username = $_POST['username'];
 $feed = $_POST['feed'];
 $hint = $_POST['hint'];
// $msg = mt_rand(000000,999999);
 //$mobile = $_POST['mobile'];
 
 
 $Sql_Query = "insert into feedback (id,username,feed,hint) values ('$id','$username','$feed','$hint')";
 
 if(mysqli_query($con,$Sql_Query)){
 
 echo 'Data Inserted Successfully';
 
 }
 else{
 
 echo 'Try Again';
 
 }
 mysqli_close($con);
?>