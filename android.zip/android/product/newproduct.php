 <?php

//This script is designed by Android-Examples.com
//Define your host here.
$hostname = "localhost";
//Define your database username here.
$username = "arunoms";
//Define your database password here.
$password = "arun@oms#2017";
//Define your database name here.
$dbname = "arunoms_test";
 
 $con = mysqli_connect($hostname,$username,$password,$dbname);
 
$np = "NP";

$mid = "1";

$sql = "SELECT * FROM newproduct WHERE token > 0";

$result=$con->query($sql);

while($row = $result->fetch_assoc())
{
	$midi = $mid;
	$midi++;

	$mid = $midi++;
}
//echo $mid;
 
 $id = $_POST['id'];
 $username = $_POST['username'];
 $product = $_POST['product'];
 $model = $_POST['model'];
 $quantity = $_POST['quantity'];
 $deldate = $_POST['deldate'];
 $conname = $_POST['conname'];
 $mobile = $_POST['mobile'];
 $status = $_POST['status'];
  
 
 $Sql_Query = "insert into newproduct (id,username,product,model,quantity,del_date,con_name,mobile,status,token,tokenname) values 
                ('$id','$username','$product','$model','$quantity','$deldate','$conname','$mobile','$status','$mid','$np')";
 
 if(mysqli_query($con,$Sql_Query)){
 
 echo $np + $mid;
 
 }
 else{
 
 echo 'Try Again';
 
 }
 mysqli_close($con);
?>