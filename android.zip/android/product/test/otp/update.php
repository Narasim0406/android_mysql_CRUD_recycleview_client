 <?php

 $hostname = "localhost";

$username = "arunoms";

$password = "arun@oms#2017";

$dbname = "arunoms_test";
 
 $con = mysqli_connect($hostname,$username,$password,$dbname);
 

 $username = $_POST['username'];
 $otp = $_POST['otp'];
 $activate = 'Y';

 
 $Sql_Query = "UPDATE users SET activated = '$activate' WHERE otp ='$otp'";
 
 if(mysqli_query($con,$Sql_Query)){
 
 echo 'OTP Verified Successfully';
 
 }
 else{
 
 echo 'Try Again';
 
 }
 mysqli_close($con);
?>