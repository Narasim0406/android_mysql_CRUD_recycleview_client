//  <?php

// $hostname = "localhost";

// $username = "arunoms";

// $password = "arun@oms#2017";

// $dbname = "arunoms_test";
 
//  $con = mysqli_connect($hostname,$username,$password,$dbname);
 

//  $otp = $_POST['otp'];
//  $password = md5($_POST['password']);
// //  $otp = mt_rand(000000, 999999);

 
//  $Sql_Query = "UPDATE users SET password = '$password'  WHERE otp = '$otp'";
 
//  if(mysqli_query($con,$Sql_Query)){
 
//  echo 'Data Inserted Successfully';
 
 
//  }
//  else{
 
//  echo 'Try Again';
 
//  }
//  mysqli_close($con);
// ?>

 <?php

//This script is designed by Android-Examples.com
//Define your host here.
$hostname = "localhost";
//Define your database username here.
$username = "arunoms";
//Define your database password here.
$password = "arun@oms#2017";
//Define your database name here.
$dbname = "arunoms_test";
 
 $con = mysqli_connect($hostname,$username,$password,$dbname);
 
 $otp = $_POST['username'];
 $password = $_POST['password'];

 
 $Sql_Query = "UPDATE users SET password = '$password'  WHERE otp = '$otp";
 
 if(mysqli_query($con,$Sql_Query)){
 
 echo 'Data Inserted Successfully';
 
 }
 else{
 
 echo 'Try Again';
 
 }
 mysqli_close($con);
?>