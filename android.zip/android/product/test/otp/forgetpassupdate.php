 <?php

$hostname = "localhost";

$username = "arunoms";

$password = "arun@oms#2017";

$dbname = "arunoms_test";
 
 $con = mysqli_connect($hostname,$username,$password,$dbname);
 

 $username = $_POST['username'];
 $email = $_POST['email'];
 $otp = mt_rand(000000, 999999);

 
 $Sql_Query = "UPDATE users SET otp = '$otp' WHERE username ='$username' AND email = '$email'";
 
 if(mysqli_query($con,$Sql_Query)){
 
//  echo 'OTP Generated Successfully';
 header('location:http://arunraaza.com/android/product/test/otp/successmsg.php');
 
 }
 else{
 
 echo 'Try Again';
 
 }
 mysqli_close($con);
?>